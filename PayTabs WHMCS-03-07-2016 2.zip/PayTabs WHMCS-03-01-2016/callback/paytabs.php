<?php	
session_start();

use WHMCS\Module\Gateway;
use WHMCS\Terminus;

/** @type WHMCS\Application $whmcs */

# Required File Includes
include "../../../init.php";
include ROOTDIR . DIRECTORY_SEPARATOR . 'includes/functions.php';
include ROOTDIR . DIRECTORY_SEPARATOR . 'includes/gatewayfunctions.php';
include ROOTDIR . DIRECTORY_SEPARATOR . 'includes/invoicefunctions.php'; 


$gatewayModule = "paytabs"; # Enter your gateway module name here replacing template


	/**
	 * Ensure that the module is active before attempting to run any code
	 */
	$gateway = new Gateway();
	if (!$gateway->isActiveGateway($gatewayModule) || !$gateway->load($gatewayModule)) {
	    Terminus::getInstance()->doDie('Module not Active');
	} 

	$GATEWAY = getGatewayVariables ( $gatewaymodule );	


		//get invoice id from return url
		$invoice_id=$_REQUEST['invoiceid'];

		//fetching paid amount from database table
		$sql="SELECT SUM(amount) as paid_amount FROM tblinvoiceitems WHERE invoiceid=".$invoice_id;
		$res=mysql_query($sql);
		if(mysql_num_rows($res)>0){
			$row=mysql_fetch_object($res);
			$amount=$row->paid_amount;
		}



		$transid=$_POST['payment_reference']; //transaction id from paytabs

		$email = $GATEWAY['Email'];
		$secret_key = $GATEWAY['SecretKey'];
		//verify paytabs payment
		$verify_fields_string= array('secret_key' =>$secret_key,
		'merchant_email'   => $email,
		'payment_reference'=> $_REQUEST['payment_reference']);

		$verify_url='https://www.paytabs.com/apiv2/verify_payment';

		$ch = @curl_init();
		@curl_setopt($ch, CURLOPT_URL, $verify_url);
		@curl_setopt($ch, CURLOPT_POST, true);
		@curl_setopt($ch, CURLOPT_POSTFIELDS, $verify_fields_string);
		@curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		@curl_setopt($ch, CURLOPT_HEADER, false);
		@curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		@curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		@curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		@curl_setopt($ch, CURLOPT_VERBOSE, true);
		$verify_result = @curl_exec($ch);
		if (!$verify_result)
		die(curl_error($ch));

		@curl_close($ch);

		//session_destroy();
		$verify_response=json_decode($verify_result);//verified response
		//print_r($verify_response);die;

		//if get response successful
		if($verify_response->response_code == 100){          
		$status=1;
		$res_msg=$verify_response->result;


		}else{  
		$status=0;		 
		$res_msg=$verify_response->result;

		}


		//invoice return 
		$return_invoice_url ='http://'.$_SERVER['HTTP_HOST'].'/whmcs/viewinvoice.php?id='.$invoice_id.'&paymentsuccess=true';
		$failed				='http://'.$_SERVER['HTTP_HOST'].'/whmcs/viewinvoice.php?id='.$invoice_id.'&paymentfailed=true';

/**
 * Check transaction Id is unique or die
 */
		checkCbInvoiceID($invoice_id,$GATEWAY["name"]); 
		if ($status==1) {
 			$invoiceid = checkCbInvoiceID($invoiceid,$GATEWAY["name"]); # Checks invoice ID is a valid invoice number or ends processing
	    	checkCbTransID($transid);
	    	addInvoicePayment($invoiceid,$transid,$amount,$fee,$gatewayModule);
			logTransaction($GATEWAY["name"],$_POST,"Successful"); 
			# Successful
			//addInvoicePayment($invoice_id,$transid,$amount,$fee,$gatewaymodule); # Apply Payment to Invoice: invoiceid, transactionid, amount paid, fees, modulename
			//logTransaction($GATEWAY["name"],$res_msg,"Successful"); # Save to Gateway Log: name, data array, status
			//after payment is successfulreturn to invoice page 
			echo '<script type="text/javascript">window.location.href="'.$return_invoice_url.'";</script>';
		} else {
			// addInvoicePayment($invoice_id,$amount,$fee,$gatewayModule); # Apply Payment to Invoice: invoiceid, transactionid, amount paid, fees, modulename
            $response = "Sorry, Transaction was not successful. The amount paid is incorrect";
            // echo $GATEWAY["name"] ."<br />";
            // print_r($_POST);
            // die();
			logTransaction($GATEWAY["name"],$_POST,"Unsuccessful");# Save to Gateway Log: name, data array, status
	        //echo '<script type="text/javascript">alert("Payment was cancelled");</script>';
	        //return array("status"=>"failed","gatewayid"=>$results["token"],"rawdata"=>$verify_response->result);
	         array("status"=>"declined","rawdata"=>'failed');
			echo '<script type="text/javascript">window.location.href="'.$failed.'";</script>'; 
		}

?>
