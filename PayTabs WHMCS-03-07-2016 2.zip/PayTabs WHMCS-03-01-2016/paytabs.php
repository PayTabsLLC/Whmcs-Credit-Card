<?php 
ob_start();
  session_start();
  ini_set('memory_limit', '-1');
    //for SMTP mail only
    require_once("PHPMailer/PHPMailerAutoload.php");
  //this function is used for paytabs configuration
    

  function paytabs_config() {
      $paytabs_configarray = array(
        "FriendlyName" => array("Type" => "System", "Value"=>"PayTabs - Third Party Payment Gateway"),
        "Email" => array("FriendlyName" => "Merchant ID", "Type" => "text", "Size" => "35", ),
        "SecretKey" => array("FriendlyName" => "Secret Key", "Type" => "text", "Size" => "55", ),
        "Instructions" => array("FriendlyName" => "Payment Instructions", "Type" => "textarea", "Rows" => "5", "Description" => "Do this then do that etc...", ),
        "testmode" => array("FriendlyName" => "Test Mode", "Type" => "yesno", "Description" => "Tick this to test", )
      );
      return $paytabs_configarray;
  }



  
  

  //this function is used for get paytabs request
  function paytabs_request($gateway_url, $fields_string){
      
      
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$gateway_url);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
      $result = @curl_exec($ch);    
      if (!$result)
      die(curl_error($ch));
      @curl_close($ch);
      return $result;
  }// end of paytabs request function

  //Check process for form submit button
  

  
  function paytabs_process($field_string) {
    
      $gateway_url='https://www.paytabs.com/apiv2/create_pay_page';
      $request_string = http_build_query($field_string);
      
      $response_data = paytabs_request($gateway_url, $request_string);
      
      return $object = json_decode($response_data);
      
  }



function sendSMTP($host,$username,$password,$port,$to,$to_name,$from,$fromname,$subject,$msg_body){

  //Create a new PHPMailer instance
  $mail = new PHPMailer;
  
  //Tell PHPMailer to use SMTP
  $mail->isSMTP();
  
  //Enable SMTP debugging
  // 0 = off (for production use)
  // 1 = client messages
  // 2 = client and server messages
  $mail->SMTPDebug = 0;
  
  //Ask for HTML-friendly debug output
  $mail->Debugoutput = 'html';
  
  //Set the hostname of the mail server
  $mail->Host = $host;
  
  //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
  $mail->Port = $port;
  
  //Set the encryption system to use - ssl (deprecated) or tls
  $mail->SMTPSecure = 'tls';
  
  //Whether to use SMTP authentication
  $mail->SMTPAuth = true;
  
  //Username to use for SMTP authentication - use full email address for gmail
  $mail->Username = $username;
  
  //Password to use for SMTP authentication
  $mail->Password = $password;
  
  //Set who the message is to be sent from
  $mail->setFrom($from, $fromname);
  
  //Set an alternative reply-to address
  //$mail->addReplyTo('replyto@example.com', 'First Last');
  
  //Set who the message is to be sent to
  $mail->addAddress($to, $to_name);
  
  //$mail->addAddress($to2, $to_name2);
  
  //Set the subject line
  $mail->Subject = $subject;
  
  //Read an HTML message body from an external file, convert referenced images to embedded,
  //convert HTML into a basic plain-text alternative body
  $mail->msgHTML($msg_body);
  
  //Replace the plain text body with one created manually
  //$mail->AltBody = 'This is a plain-text message body';
  
  //Attach an image file
  //$mail->addAttachment('images/phpmailer_mini.png');
  
  //send the message, check for errors
  if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
    exit;
    return 0;
  } else {
    //echo "Message sent!";
    return 1;
  }
}//end of function SMTP
  

function get_full_url($s)
{
    $ssl = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on') ? true:false;
    $sp = strtolower($s['SERVER_PROTOCOL']);
    $protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
    $port = $s['SERVER_PORT'];
    $port = ((!$ssl && $port=='80') || ($ssl && $port=='443')) ? '' : ':'.$port;
    $host = isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : $s['SERVER_NAME'];
    //$protocol . '://' . $host . $port . $s['REQUEST_URI'];
   
    return $protocol . '://' . $host .  $s['REQUEST_URI'];
}


function sendmail($body,$to,$subject,$from,$from_name)
{
   // $from='testing@gmail.com';      
    $headersfrom='';
    $headersfrom .= 'MIME-Version: 1.0' . "\r\n";
    $headersfrom .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headersfrom .= 'From: '.$from_name.'<'.$from.'> '. "\r\n";
    mail($to,$subject,$body,$headersfrom);
}  


  function getccPhone($code){
        $countries = array(
          "AF" => '+93',//array("AFGHANISTAN", "AF", "AFG", "004"),
          "AL" => '+355',//array("ALBANIA", "AL", "ALB", "008"),
          "DZ" => '+213',//array("ALGERIA", "DZ", "DZA", "012"),
          "AS" => '+376',//array("AMERICAN SAMOA", "AS", "ASM", "016"),
          "AD" => '+376',//array("ANDORRA", "AD", "AND", "020"),
          "AO" => '+244',//array("ANGOLA", "AO", "AGO", "024"),
          "AG" => '+1-268',//array("ANTIGUA AND BARBUDA", "AG", "ATG", "028"),
          "AR" => '+54',//array("ARGENTINA", "AR", "ARG", "032"),
          "AM" => '+374',//array("ARMENIA", "AM", "ARM", "051"),
          "AU" => '+61',//array("AUSTRALIA", "AU", "AUS", "036"),
          "AT" => '+43',//array("AUSTRIA", "AT", "AUT", "040"),
          "AZ" => '+994',//array("AZERBAIJAN", "AZ", "AZE", "031"),
          "BS" => '+1-242',//array("BAHAMAS", "BS", "BHS", "044"),
          "BH" => '+973',//array("BAHRAIN", "BH", "BHR", "048"),
          "BD" => '+880',//array("BANGLADESH", "BD", "BGD", "050"),
          "BB" => '1-246',//array("BARBADOS", "BB", "BRB", "052"),
          "BY" => '+375',//array("BELARUS", "BY", "BLR", "112"),
          "BE" => '+32',//array("BELGIUM", "BE", "BEL", "056"),
          "BZ" => '+501',//array("BELIZE", "BZ", "BLZ", "084"),
          "BJ" =>'+229',// array("BENIN", "BJ", "BEN", "204"),
          "BT" => '+975',//array("BHUTAN", "BT", "BTN", "064"),
          "BO" => '+591',//array("BOLIVIA", "BO", "BOL", "068"),
          "BA" => '+387',//array("BOSNIA AND HERZEGOVINA", "BA", "BIH", "070"),
          "BW" => '+267',//array("BOTSWANA", "BW", "BWA", "072"),
          "BR" => '+55',//array("BRAZIL", "BR", "BRA", "076"),
          "BN" => '+673',//array("BRUNEI DARUSSALAM", "BN", "BRN", "096"),
          "BG" => '+359',//array("BULGARIA", "BG", "BGR", "100"),
          "BF" => '+226',//array("BURKINA FASO", "BF", "BFA", "854"),
          "BI" => '+257',//array("BURUNDI", "BI", "BDI", "108"),
          "KH" => '+855',//array("CAMBODIA", "KH", "KHM", "116"),
          "CA" => '+1',//array("CANADA", "CA", "CAN", "124"),
          "CV" => '+238',//array("CAPE VERDE", "CV", "CPV", "132"),
          "CF" => '+236',//array("CENTRAL AFRICAN REPUBLIC", "CF", "CAF", "140"),
          "CM" => '+237',//array("CENTRAL AFRICAN REPUBLIC", "CF", "CAF", "140"),
          "TD" => '+235',//array("CHAD", "TD", "TCD", "148"),
          "CL" => '+56',//array("CHILE", "CL", "CHL", "152"),
          "CN" => '+86',//array("CHINA", "CN", "CHN", "156"),
          "CO" => '+57',//array("COLOMBIA", "CO", "COL", "170"),
          "KM" => '+269',//array("COMOROS", "KM", "COM", "174"),
          "CG" => '+242',//array("CONGO", "CG", "COG", "178"),
          "CR" => '+506',//array("COSTA RICA", "CR", "CRI", "188"),
          "CI" => '+225',//array("COTE D'IVOIRE", "CI", "CIV", "384"),
          "HR" => '+385',//array("CROATIA (local name: Hrvatska)", "HR", "HRV", "191"),
          "CU" => '+53',//array("CUBA", "CU", "CUB", "192"),
          "CY" => '+357',//array("CYPRUS", "CY", "CYP", "196"),
          "CZ" => '+420',//array("CZECH REPUBLIC", "CZ", "CZE", "203"),
          "DK" => '+45',//array("DENMARK", "DK", "DNK", "208"),
          "DJ" => '+253',//array("DJIBOUTI", "DJ", "DJI", "262"),
          "DM" => '+1-767',//array("DOMINICA", "DM", "DMA", "212"),
          "DO" => '+1-809',//array("DOMINICAN REPUBLIC", "DO", "DOM", "214"),
          "EC" => '+593',//array("ECUADOR", "EC", "ECU", "218"),
          "EG" => '+20',//array("EGYPT", "EG", "EGY", "818"),
          "SV" => '+503',//array("EL SALVADOR", "SV", "SLV", "222"),
          "GQ" => '+240',//array("EQUATORIAL GUINEA", "GQ", "GNQ", "226"),
          "ER" => '+291',//array("ERITREA", "ER", "ERI", "232"),
          "EE" => '+372',//array("ESTONIA", "EE", "EST", "233"),
          "ET" => '+251',//array("ETHIOPIA", "ET", "ETH", "210"),
          "FJ" => '+679',//array("FIJI", "FJ", "FJI", "242"),
          "FI" => '+358',//array("FINLAND", "FI", "FIN", "246"),
          "FR" => '+33',//array("FRANCE", "FR", "FRA", "250"),
          "GA" => '+241',//array("GABON", "GA", "GAB", "266"),
          "GM" => '+220',//array("GAMBIA", "GM", "GMB", "270"),
          "GE" => '+995',//array("GEORGIA", "GE", "GEO", "268"),
          "DE" => '+49',//array("GERMANY", "DE", "DEU", "276"),
          "GH" => '+233',//array("GHANA", "GH", "GHA", "288"),
          "GR" => '+30',//array("GREECE", "GR", "GRC", "300"),
          "GD" => '+1-473',//array("GRENADA", "GD", "GRD", "308"),
          "GT" => '+502',//array("GUATEMALA", "GT", "GTM", "320"),
          "GN" => '+224',//array("GUINEA", "GN", "GIN", "324"),
          "GW" => '+245',//array("GUINEA-BISSAU", "GW", "GNB", "624"),
          "GY" => '+592',//array("GUYANA", "GY", "GUY", "328"),
          "HT" => '+509',//array("HAITI", "HT", "HTI", "332"),
          "HN" => '+504',//array("HONDURAS", "HN", "HND", "340"),
          "HK" => '+852',//array("HONG KONG", "HK", "HKG", "344"),
          "HU" => '+36',//array("HUNGARY", "HU", "HUN", "348"),
          "IS" => '+354',//array("ICELAND", "IS", "ISL", "352"),
          "IN" => '+91',//array("INDIA", "IN", "IND", "356"),
          "ID" => '+62',//array("INDONESIA", "ID", "IDN", "360"),
          "IR" => '+98',//array("IRAN, ISLAMIC REPUBLIC OF", "IR", "IRN", "364"),
          "IQ" => '+964',//array("IRAQ", "IQ", "IRQ", "368"),
          "IE" => '+353',//array("IRELAND", "IE", "IRL", "372"),
          "IL" => '+972',//array("ISRAEL", "IL", "ISR", "376"),
          "IT" => '+39',//array("ITALY", "IT", "ITA", "380"),
          "JM" => '+1-876',//array("JAMAICA", "JM", "JAM", "388"),
          "JP" => '+81',//array("JAPAN", "JP", "JPN", "392"),
          "JO" => '+962',//array("JORDAN", "JO", "JOR", "400"),
          "KZ" => '+7',//array("KAZAKHSTAN", "KZ", "KAZ", "398"),
          "KE" => '+254',//array("KENYA", "KE", "KEN", "404"),
          "KI" => '+686',//array("KIRIBATI", "KI", "KIR", "296"),
          "KP" => '+850',//array("KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF", "KP", "PRK", "408"),
          "KR" => '+82',//array("KOREA, REPUBLIC OF", "KR", "KOR", "410"),
          "KW" => '+965',//array("KUWAIT", "KW", "KWT", "414"),
          "KG" => '+996',//array("KYRGYZSTAN", "KG", "KGZ", "417"),
          "LA" => '+856',//array("LAO PEOPLE'S DEMOCRATIC REPUBLIC", "LA", "LAO", "418"),
          "LV" => '+371',//array("LATVIA", "LV", "LVA", "428"),
          "LB" => '+961',//array("LEBANON", "LB", "LBN", "422"),
          "LS" => '+266',//array("LESOTHO", "LS", "LSO", "426"),
          "LR" => '+231',//array("LIBERIA", "LR", "LBR", "430"),
          "LY" => '+218',//array("LIBYAN ARAB JAMAHIRIYA", "LY", "LBY", "434"),
          "LI" => '+423',//array("LIECHTENSTEIN", "LI", "LIE", "438"),
          "LU" => '+352',//array("LUXEMBOURG", "LU", "LUX", "442"),
          "MO" => '+389',//array("MACAU", "MO", "MAC", "446"),
          "MG" => '+261',//array("MADAGASCAR", "MG", "MDG", "450"),
          "MW" => '+265',//array("MALAWI", "MW", "MWI", "454"),
          "MY" => '+60',//array("MALAYSIA", "MY", "MYS", "458"),     
          "MX" => '+52',//array("MEXICO", "MX", "MEX", "484"),
          "MC" => '+377',//array("MONACO", "MC", "MCO", "492"),
          "MA" => '+212',//array("MOROCCO", "MA", "MAR", "504")
          "NP" => '+977',//array("NEPAL", "NP", "NPL", "524"),
          "NL" => '+31',//array("NETHERLANDS", "NL", "NLD", "528"),
          "NZ" => '+64',//array("NEW ZEALAND", "NZ", "NZL", "554"),
          "NI" => '+505',//array("NICARAGUA", "NI", "NIC", "558"),
          "NE" => '+227',//array("NIGER", "NE", "NER", "562"),
          "NG" => '+234',//array("NIGERIA", "NG", "NGA", "566"),
          "NO" => '+47',//array("NORWAY", "NO", "NOR", "578"),
          "OM" => '+968',//array("OMAN", "OM", "OMN", "512"),
          "PK" => '+92',//array("PAKISTAN", "PK", "PAK", "586"),
          "PA" => '+507',//array("PANAMA", "PA", "PAN", "591"),
          "PG" => '+675',//array("PAPUA NEW GUINEA", "PG", "PNG", "598"),
          "PY" =>'+595',// array("PARAGUAY", "PY", "PRY", "600"),
          "PE" =>'+51',// array("PERU", "PE", "PER", "604"),
          "PH" =>'+63',// array("PHILIPPINES", "PH", "PHL", "608"),
          "PL" => '48',//array("POLAND", "PL", "POL", "616"),
          "PT" => '+351',//array("PORTUGAL", "PT", "PRT", "620"),
          "QA" => '+974',//array("QATAR", "QA", "QAT", "634"),
          "RU" => '+7',//array("RUSSIAN FEDERATION", "RU", "RUS", "643"),
          "RW" => '+250',//array("RWANDA", "RW", "RWA", "646"),
          "SA" => '+966',//array("SAUDI ARABIA", "SA", "SAU", "682"),
          "SN" => '+221',//array("SENEGAL", "SN", "SEN", "686"),
          "SG" => '+65',//array("SINGAPORE", "SG", "SGP", "702"),
          "SK" => '+421',//array("SLOVAKIA (Slovak Republic)", "SK", "SVK", "703"),
          "SI" => '+386',//array("SLOVENIA", "SI", "SVN", "705"),
          "ZA" => '+27',//array("SOUTH AFRICA", "ZA", "ZAF", "710"),
          "ES" => '+34',//array("SPAIN", "ES", "ESP", "724"),
          "LK" => '+94',//array("SRI LANKA", "LK", "LKA", "144"),
          "SD" => '+249',//array("SUDAN", "SD", "SDN", "736"),
          "SZ" => '+268',//array("SWAZILAND", "SZ", "SWZ", "748"),
          "SE" => '+46',//array("SWEDEN", "SE", "SWE", "752"),
          "CH" => '+41',//array("SWITZERLAND", "CH", "CHE", "756"),
          "SY" => '+963',//array("SYRIAN ARAB REPUBLIC", "SY", "SYR", "760"),
          "TZ" => '+255',//array("TANZANIA, UNITED REPUBLIC OF", "TZ", "TZA", "834"),
          "TH" => '+66',//array("THAILAND", "TH", "THA", "764"),
          "TG" => '+228',//array("TOGO", "TG", "TGO", "768"),
          "TO" => '+676',//array("TONGA", "TO", "TON", "776"),
          "TN" => '+216',//array("TUNISIA", "TN", "TUN", "788"),
          "TR" => '+90',//array("TURKEY", "TR", "TUR", "792"),
          "TM" => '+993',//array("TURKMENISTAN", "TM", "TKM", "795"),
          "UA" => '+380',//array("UKRAINE", "UA", "UKR", "804"),
          "AE" => '+971',//array("UNITED ARAB EMIRATES", "AE", "ARE", "784"),
          "GB" => '+44',//array("UNITED KINGDOM", "GB", "GBR", "826"),
          "US" => '+1'//array("UNITED STATES", "US", "USA", "840"),
          
        );

    
      return $countries[$code];
    }     

   /*
    Get country code function 
    */
    function getCountryIsoCode($code){
        $countries = array(
          "AF" => array("AFGHANISTAN", "AF", "AFG", "004"),
          "AL" => array("ALBANIA", "AL", "ALB", "008"),
          "DZ" => array("ALGERIA", "DZ", "DZA", "012"),
          "AS" => array("AMERICAN SAMOA", "AS", "ASM", "016"),
          "AD" => array("ANDORRA", "AD", "AND", "020"),
          "AO" => array("ANGOLA", "AO", "AGO", "024"),
          "AI" => array("ANGUILLA", "AI", "AIA", "660"),
          "AQ" => array("ANTARCTICA", "AQ", "ATA", "010"),
          "AG" => array("ANTIGUA AND BARBUDA", "AG", "ATG", "028"),
          "AR" => array("ARGENTINA", "AR", "ARG", "032"),
          "AM" => array("ARMENIA", "AM", "ARM", "051"),
          "AW" => array("ARUBA", "AW", "ABW", "533"),
          "AU" => array("AUSTRALIA", "AU", "AUS", "036"),
          "AT" => array("AUSTRIA", "AT", "AUT", "040"),
          "AZ" => array("AZERBAIJAN", "AZ", "AZE", "031"),
          "BS" => array("BAHAMAS", "BS", "BHS", "044"),
          "BH" => array("BAHRAIN", "BH", "BHR", "048"),
          "BD" => array("BANGLADESH", "BD", "BGD", "050"),
          "BB" => array("BARBADOS", "BB", "BRB", "052"),
          "BY" => array("BELARUS", "BY", "BLR", "112"),
          "BE" => array("BELGIUM", "BE", "BEL", "056"),
          "BZ" => array("BELIZE", "BZ", "BLZ", "084"),
          "BJ" => array("BENIN", "BJ", "BEN", "204"),
          "BM" => array("BERMUDA", "BM", "BMU", "060"),
          "BT" => array("BHUTAN", "BT", "BTN", "064"),
          "BO" => array("BOLIVIA", "BO", "BOL", "068"),
          "BA" => array("BOSNIA AND HERZEGOVINA", "BA", "BIH", "070"),
          "BW" => array("BOTSWANA", "BW", "BWA", "072"),
          "BV" => array("BOUVET ISLAND", "BV", "BVT", "074"),
          "BR" => array("BRAZIL", "BR", "BRA", "076"),
          "IO" => array("BRITISH INDIAN OCEAN TERRITORY", "IO", "IOT", "086"),
          "BN" => array("BRUNEI DARUSSALAM", "BN", "BRN", "096"),
          "BG" => array("BULGARIA", "BG", "BGR", "100"),
          "BF" => array("BURKINA FASO", "BF", "BFA", "854"),
          "BI" => array("BURUNDI", "BI", "BDI", "108"),
          "KH" => array("CAMBODIA", "KH", "KHM", "116"),
          "CM" => array("CAMEROON", "CM", "CMR", "120"),
          "CA" => array("CANADA", "CA", "CAN", "124"),
          "CV" => array("CAPE VERDE", "CV", "CPV", "132"),
          "KY" => array("CAYMAN ISLANDS", "KY", "CYM", "136"),
          "CF" => array("CENTRAL AFRICAN REPUBLIC", "CF", "CAF", "140"),
          "TD" => array("CHAD", "TD", "TCD", "148"),
          "CL" => array("CHILE", "CL", "CHL", "152"),
          "CN" => array("CHINA", "CN", "CHN", "156"),
          "CX" => array("CHRISTMAS ISLAND", "CX", "CXR", "162"),
          "CC" => array("COCOS (KEELING) ISLANDS", "CC", "CCK", "166"),
          "CO" => array("COLOMBIA", "CO", "COL", "170"),
          "KM" => array("COMOROS", "KM", "COM", "174"),
          "CG" => array("CONGO", "CG", "COG", "178"),
          "CK" => array("COOK ISLANDS", "CK", "COK", "184"),
          "CR" => array("COSTA RICA", "CR", "CRI", "188"),
          "CI" => array("COTE D'IVOIRE", "CI", "CIV", "384"),
          "HR" => array("CROATIA (local name: Hrvatska)", "HR", "HRV", "191"),
          "CU" => array("CUBA", "CU", "CUB", "192"),
          "CY" => array("CYPRUS", "CY", "CYP", "196"),
          "CZ" => array("CZECH REPUBLIC", "CZ", "CZE", "203"),
          "DK" => array("DENMARK", "DK", "DNK", "208"),
          "DJ" => array("DJIBOUTI", "DJ", "DJI", "262"),
          "DM" => array("DOMINICA", "DM", "DMA", "212"),
          "DO" => array("DOMINICAN REPUBLIC", "DO", "DOM", "214"),
          "TL" => array("EAST TIMOR", "TL", "TLS", "626"),
          "EC" => array("ECUADOR", "EC", "ECU", "218"),
          "EG" => array("EGYPT", "EG", "EGY", "818"),
          "SV" => array("EL SALVADOR", "SV", "SLV", "222"),
          "GQ" => array("EQUATORIAL GUINEA", "GQ", "GNQ", "226"),
          "ER" => array("ERITREA", "ER", "ERI", "232"),
          "EE" => array("ESTONIA", "EE", "EST", "233"),
          "ET" => array("ETHIOPIA", "ET", "ETH", "210"),
          "FK" => array("FALKLAND ISLANDS (MALVINAS)", "FK", "FLK", "238"),
          "FO" => array("FAROE ISLANDS", "FO", "FRO", "234"),
          "FJ" => array("FIJI", "FJ", "FJI", "242"),
          "FI" => array("FINLAND", "FI", "FIN", "246"),
          "FR" => array("FRANCE", "FR", "FRA", "250"),
          "FX" => array("FRANCE, METROPOLITAN", "FX", "FXX", "249"),
          "GF" => array("FRENCH GUIANA", "GF", "GUF", "254"),
          "PF" => array("FRENCH POLYNESIA", "PF", "PYF", "258"),
          "TF" => array("FRENCH SOUTHERN TERRITORIES", "TF", "ATF", "260"),
          "GA" => array("GABON", "GA", "GAB", "266"),
          "GM" => array("GAMBIA", "GM", "GMB", "270"),
          "GE" => array("GEORGIA", "GE", "GEO", "268"),
          "DE" => array("GERMANY", "DE", "DEU", "276"),
          "GH" => array("GHANA", "GH", "GHA", "288"),
          "GI" => array("GIBRALTAR", "GI", "GIB", "292"),
          "GR" => array("GREECE", "GR", "GRC", "300"),
          "GL" => array("GREENLAND", "GL", "GRL", "304"),
          "GD" => array("GRENADA", "GD", "GRD", "308"),
          "GP" => array("GUADELOUPE", "GP", "GLP", "312"),
          "GU" => array("GUAM", "GU", "GUM", "316"),
          "GT" => array("GUATEMALA", "GT", "GTM", "320"),
          "GN" => array("GUINEA", "GN", "GIN", "324"),
          "GW" => array("GUINEA-BISSAU", "GW", "GNB", "624"),
          "GY" => array("GUYANA", "GY", "GUY", "328"),
          "HT" => array("HAITI", "HT", "HTI", "332"),
          "HM" => array("HEARD ISLAND & MCDONALD ISLANDS", "HM", "HMD", "334"),
          "HN" => array("HONDURAS", "HN", "HND", "340"),
          "HK" => array("HONG KONG", "HK", "HKG", "344"),
          "HU" => array("HUNGARY", "HU", "HUN", "348"),
          "IS" => array("ICELAND", "IS", "ISL", "352"),
          "IN" => array("INDIA", "IN", "IND", "356"),
          "ID" => array("INDONESIA", "ID", "IDN", "360"),
          "IR" => array("IRAN, ISLAMIC REPUBLIC OF", "IR", "IRN", "364"),
          "IQ" => array("IRAQ", "IQ", "IRQ", "368"),
          "IE" => array("IRELAND", "IE", "IRL", "372"),
          "IL" => array("ISRAEL", "IL", "ISR", "376"),
          "IT" => array("ITALY", "IT", "ITA", "380"),
          "JM" => array("JAMAICA", "JM", "JAM", "388"),
          "JP" => array("JAPAN", "JP", "JPN", "392"),
          "JO" => array("JORDAN", "JO", "JOR", "400"),
          "KZ" => array("KAZAKHSTAN", "KZ", "KAZ", "398"),
          "KE" => array("KENYA", "KE", "KEN", "404"),
          "KI" => array("KIRIBATI", "KI", "KIR", "296"),
          "KP" => array("KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF", "KP", "PRK", "408"),
          "KR" => array("KOREA, REPUBLIC OF", "KR", "KOR", "410"),
          "KW" => array("KUWAIT", "KW", "KWT", "414"),
          "KG" => array("KYRGYZSTAN", "KG", "KGZ", "417"),
          "LA" => array("LAO PEOPLE'S DEMOCRATIC REPUBLIC", "LA", "LAO", "418"),
          "LV" => array("LATVIA", "LV", "LVA", "428"),
          "LB" => array("LEBANON", "LB", "LBN", "422"),
          "LS" => array("LESOTHO", "LS", "LSO", "426"),
          "LR" => array("LIBERIA", "LR", "LBR", "430"),
          "LY" => array("LIBYAN ARAB JAMAHIRIYA", "LY", "LBY", "434"),
          "LI" => array("LIECHTENSTEIN", "LI", "LIE", "438"),
          "LT" => array("LITHUANIA", "LT", "LTU", "440"),
          "LU" => array("LUXEMBOURG", "LU", "LUX", "442"),
          "MO" => array("MACAU", "MO", "MAC", "446"),
          "MK" => array("MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF", "MK", "MKD", "807"),
          "MG" => array("MADAGASCAR", "MG", "MDG", "450"),
          "MW" => array("MALAWI", "MW", "MWI", "454"),
          "MY" => array("MALAYSIA", "MY", "MYS", "458"),
          "MV" => array("MALDIVES", "MV", "MDV", "462"),
          "ML" => array("MALI", "ML", "MLI", "466"),
          "MT" => array("MALTA", "MT", "MLT", "470"),
          "MH" => array("MARSHALL ISLANDS", "MH", "MHL", "584"),
          "MQ" => array("MARTINIQUE", "MQ", "MTQ", "474"),
          "MR" => array("MAURITANIA", "MR", "MRT", "478"),
          "MU" => array("MAURITIUS", "MU", "MUS", "480"),
          "YT" => array("MAYOTTE", "YT", "MYT", "175"),
          "MX" => array("MEXICO", "MX", "MEX", "484"),
          "FM" => array("MICRONESIA, FEDERATED STATES OF", "FM", "FSM", "583"),
          "MD" => array("MOLDOVA, REPUBLIC OF", "MD", "MDA", "498"),
          "MC" => array("MONACO", "MC", "MCO", "492"),
          "MN" => array("MONGOLIA", "MN", "MNG", "496"),
          "MS" => array("MONTSERRAT", "MS", "MSR", "500"),
          "MA" => array("MOROCCO", "MA", "MAR", "504"),
          "MZ" => array("MOZAMBIQUE", "MZ", "MOZ", "508"),
          "MM" => array("MYANMAR", "MM", "MMR", "104"),
          "NA" => array("NAMIBIA", "NA", "NAM", "516"),
          "NR" => array("NAURU", "NR", "NRU", "520"),
          "NP" => array("NEPAL", "NP", "NPL", "524"),
          "NL" => array("NETHERLANDS", "NL", "NLD", "528"),
          "AN" => array("NETHERLANDS ANTILLES", "AN", "ANT", "530"),
          "NC" => array("NEW CALEDONIA", "NC", "NCL", "540"),
          "NZ" => array("NEW ZEALAND", "NZ", "NZL", "554"),
          "NI" => array("NICARAGUA", "NI", "NIC", "558"),
          "NE" => array("NIGER", "NE", "NER", "562"),
          "NG" => array("NIGERIA", "NG", "NGA", "566"),
          "NU" => array("NIUE", "NU", "NIU", "570"),
          "NF" => array("NORFOLK ISLAND", "NF", "NFK", "574"),
          "MP" => array("NORTHERN MARIANA ISLANDS", "MP", "MNP", "580"),
          "NO" => array("NORWAY", "NO", "NOR", "578"),
          "OM" => array("OMAN", "OM", "OMN", "512"),
          "PK" => array("PAKISTAN", "PK", "PAK", "586"),
          "PW" => array("PALAU", "PW", "PLW", "585"),
          "PA" => array("PANAMA", "PA", "PAN", "591"),
          "PG" => array("PAPUA NEW GUINEA", "PG", "PNG", "598"),
          "PY" => array("PARAGUAY", "PY", "PRY", "600"),
          "PE" => array("PERU", "PE", "PER", "604"),
          "PH" => array("PHILIPPINES", "PH", "PHL", "608"),
          "PN" => array("PITCAIRN", "PN", "PCN", "612"),
          "PL" => array("POLAND", "PL", "POL", "616"),
          "PT" => array("PORTUGAL", "PT", "PRT", "620"),
          "PR" => array("PUERTO RICO", "PR", "PRI", "630"),
          "QA" => array("QATAR", "QA", "QAT", "634"),
          "RE" => array("REUNION", "RE", "REU", "638"),
          "RO" => array("ROMANIA", "RO", "ROU", "642"),
          "RU" => array("RUSSIAN FEDERATION", "RU", "RUS", "643"),
          "RW" => array("RWANDA", "RW", "RWA", "646"),
          "KN" => array("SAINT KITTS AND NEVIS", "KN", "KNA", "659"),
          "LC" => array("SAINT LUCIA", "LC", "LCA", "662"),
          "VC" => array("SAINT VINCENT AND THE GRENADINES", "VC", "VCT", "670"),
          "WS" => array("SAMOA", "WS", "WSM", "882"),
          "SM" => array("SAN MARINO", "SM", "SMR", "674"),
          "ST" => array("SAO TOME AND PRINCIPE", "ST", "STP", "678"),
          "SA" => array("SAUDI ARABIA", "SA", "SAU", "682"),
          "SN" => array("SENEGAL", "SN", "SEN", "686"),
          "RS" => array("SERBIA", "RS", "SRB", "688"),
          "SC" => array("SEYCHELLES", "SC", "SYC", "690"),
          "SL" => array("SIERRA LEONE", "SL", "SLE", "694"),
          "SG" => array("SINGAPORE", "SG", "SGP", "702"),
          "SK" => array("SLOVAKIA (Slovak Republic)", "SK", "SVK", "703"),
          "SI" => array("SLOVENIA", "SI", "SVN", "705"),
          "SB" => array("SOLOMON ISLANDS", "SB", "SLB", "90"),
          "SO" => array("SOMALIA", "SO", "SOM", "706"),
          "ZA" => array("SOUTH AFRICA", "ZA", "ZAF", "710"),
          "ES" => array("SPAIN", "ES", "ESP", "724"),
          "LK" => array("SRI LANKA", "LK", "LKA", "144"),
          "SH" => array("SAINT HELENA", "SH", "SHN", "654"),
          "PM" => array("SAINT PIERRE AND MIQUELON", "PM", "SPM", "666"),
          "SD" => array("SUDAN", "SD", "SDN", "736"),
          "SR" => array("SURINAME", "SR", "SUR", "740"),
          "SJ" => array("SVALBARD AND JAN MAYEN ISLANDS", "SJ", "SJM", "744"),
          "SZ" => array("SWAZILAND", "SZ", "SWZ", "748"),
          "SE" => array("SWEDEN", "SE", "SWE", "752"),
          "CH" => array("SWITZERLAND", "CH", "CHE", "756"),
          "SY" => array("SYRIAN ARAB REPUBLIC", "SY", "SYR", "760"),
          "TW" => array("TAIWAN, PROVINCE OF CHINA", "TW", "TWN", "158"),
          "TJ" => array("TAJIKISTAN", "TJ", "TJK", "762"),
          "TZ" => array("TANZANIA, UNITED REPUBLIC OF", "TZ", "TZA", "834"),
          "TH" => array("THAILAND", "TH", "THA", "764"),
          "TG" => array("TOGO", "TG", "TGO", "768"),
          "TK" => array("TOKELAU", "TK", "TKL", "772"),
          "TO" => array("TONGA", "TO", "TON", "776"),
          "TT" => array("TRINIDAD AND TOBAGO", "TT", "TTO", "780"),
          "TN" => array("TUNISIA", "TN", "TUN", "788"),
          "TR" => array("TURKEY", "TR", "TUR", "792"),
          "TM" => array("TURKMENISTAN", "TM", "TKM", "795"),
          "TC" => array("TURKS AND CAICOS ISLANDS", "TC", "TCA", "796"),
          "TV" => array("TUVALU", "TV", "TUV", "798"),
          "UG" => array("UGANDA", "UG", "UGA", "800"),
          "UA" => array("UKRAINE", "UA", "UKR", "804"),
          "AE" => array("UNITED ARAB EMIRATES", "AE", "ARE", "784"),
          "GB" => array("UNITED KINGDOM", "GB", "GBR", "826"),
          "US" => array("UNITED STATES", "US", "USA", "840"),
          "UM" => array("UNITED STATES MINOR OUTLYING ISLANDS", "UM", "UMI", "581"),
          "UY" => array("URUGUAY", "UY", "URY", "858"),
          "UZ" => array("UZBEKISTAN", "UZ", "UZB", "860"),
          "VU" => array("VANUATU", "VU", "VUT", "548"),
          "VA" => array("VATICAN CITY STATE (HOLY SEE)", "VA", "VAT", "336"),
          "VE" => array("VENEZUELA", "VE", "VEN", "862"),
          "VN" => array("VIET NAM", "VN", "VNM", "704"),
          "VG" => array("VIRGIN ISLANDS (BRITISH)", "VG", "VGB", "92"),
          "VI" => array("VIRGIN ISLANDS (U.S.)", "VI", "VIR", "850"),
          "WF" => array("WALLIS AND FUTUNA ISLANDS", "WF", "WLF", "876"),
          "EH" => array("WESTERN SAHARA", "EH", "ESH", "732"),
          "YE" => array("YEMEN", "YE", "YEM", "887"),
          "YU" => array("YUGOSLAVIA", "YU", "YUG", "891"),
          "ZR" => array("ZAIRE", "ZR", "ZAR", "180"),
          "ZM" => array("ZAMBIA", "ZM", "ZMB", "894"),
          "ZW" => array("ZIMBABWE", "ZW", "ZWE", "716"),
        );
    
      return $countries[$code][2];
    
  }


//this function is used for getting form data from whmcs to paytabs
function paytabs_link($params) {
 //$smtp_debug='true';

  if (strchr($_SERVER['HTTP_REFERER'], "callback")){
    return ;
  }




      $site_url = dirname(dirname(get_full_url($_SERVER)));

      $invoiceid = $params['invoiceid'];

      $description = $params["description"];

      $Email = $params['Email'];
      $SecretKey = $params['SecretKey'];
        
      $_SESSION['email'] = $Email;  
      $_SESSION['secret_key'] = $SecretKey; 
      # Invoice Variables

      $amount = $params['amount']; # Format: ##.##
      $currency = $params['currency']; # Currency Code

      # Client Variables
      $firstname = $params['clientdetails']['firstname'];
      $lastname = $params['clientdetails']['lastname'];
      $email = $params['clientdetails']['email'];
      $address1 = $params['clientdetails']['address1'];
      $address2 = $params['clientdetails']['address2'];
      $city = $params['clientdetails']['city'];
      $state = $params['clientdetails']['fullstate'];
      $postcode = $params['clientdetails']['postcode'];
      $country = $params['clientdetails']['country'];
      $phone = $params['clientdetails']['phonenumber'];
      //$return_url = $params['returnurl'];
      
      
     // $return_url = 'http://my.weappz.com/modules/gateways/callback/paytabs.php?invoiceid='.$params['invoiceid'];
      $return_url = $site_url.'/modules/gateways/callback/paytabs.php?invoiceid='.$params['invoiceid'];

      # System Variables
      $companyname = $params['companyname'];
      $systemurl = $params['systemurl'];
            
      
      # Enter your code submit to the gateway...

      $billing_address=$address1.' '.$address2;

      $cart_products=$_SESSION['cart']['products'];
      
      $cart_products_domains=$_SESSION['cart']['domains'];

  
      $product_str_arr=array();
      $qty=0;
      
    if(!empty($cart_products))
     {
      foreach($cart_products as $products)
        {
      $product_str_arr[]= $products['domain'];


      }
     }
      
      if(!empty($cart_products_domains)) {
        
        foreach($cart_products_domains as $domain){
           $product_str_arr[]= $domain['domain'];
        }
      }
    
      
      $qty=count(array_values($product_str_arr));
    
      /*$qry_arr=array();
      
      for($i=1;$i<=$qty1; $i++){                  
          $qry_arr[]=1;
          

      }*/
      $unit_price=$amount/$qty;
        
       $products_per_title=implode(' | ',$product_str_arr);
      
      if ($_SERVER['SERVER_PORT']==443) {
      $protocol='https://';
    }else{
      $protocol='http://';
    }
    
     $product_id = intval($_SESSION['cart']['domainoptionspid']);

      $query = mysql_query('select name,description from tblproducts where id="'.$product_id.'" ');
      $query1 = mysql_fetch_assoc($query);

      $name_product= $query1['name'];
      $description_product= $query1['description'];

      $post_arr_to_paytabs=array(
          'merchant_email'   => $Email,
          'secret_key'       => $SecretKey,
          'amount'           => $amount,
          'firstname'        => $firstname,
          'lastname'         => $lastname,
          'email'            => $email,
          'billing_address'  => $billing_address,
          'address_shipping' => $billing_address,
          'address1'         => $address1,
          'address2'         => $address2,
          'city'             => $city,
          'state'            => $state,
          'country'          => $country,
          'city_shipping'    => $city,
          'state_shipping'   => $state,
          'country'          => getCountryIsoCode($country),
          'country_shipping' => getCountryIsoCode($country),
          'zipcode'          => $postcode,
          'phone'            => $phone,
          'cc_phone_number'  => getccPhone($country),
          'cc_first_name'    => $firstname,
          'cc_last_name'     => $lastname,
          'phone_number'     => $phone,
          'postal_code'      => $postcode,
          'postal_code_shipping'=>$postcode,
          'currency'         => $currency,
          'title'            => $firstname.' '.$lastname,
          'products_per_title'     => $products_per_title == '' ? $description_product : $products_per_title,//$name_product,
          'description'      => $products_per_title == '' ? $description_product : $products_per_title,//$name_product, //$products_per_title == '' ? $description_product :$products_per_title,
          'quantity'         => $qty,
          'unit_price'       => $unit_price,
          'other_charges'    => 0,
          'return_url'       => $return_url,
          'invoiceid'        => $invoiceid,
          'ip_customer'      => $_SERVER['REMOTE_ADDR'],
          'ip_merchant'      => $_SERVER['SERVER_ADDR'],
          'cms_with_version' =>$params['whmcsVersion'],
          'reference_no'     => $invoiceid,
          'site_url'         => $protocol.$_SERVER['HTTP_HOST'],
          'msg_lang'         => 'English'
          );
    



    $send_remainder_redirect=$site_url.'/admin/invoices.php?filter=1';
    
      $ID= $_GET['id'];
      $query = "SELECT inv.userid, CONCAT_WS(' ', c.firstname, c.lastname) as name,c.email,DATE_FORMAT(inv.date,'%d/%m/%y') as inv_created,DATE_FORMAT(inv.duedate,'%d/%m/%y') as inv_duedate,inv.paymentmethod,inv.subtotal as invoice_balance FROM tblinvoices inv INNER JOIN tblclients c ON inv.userid = c.id WHERE inv.id = '" . $ID ."'";
      $row_email=mysql_fetch_object(mysql_query($query));

      $to_email = $row_email->email;
    
    $r=mysql_query("SELECT * FROM tblinvoiceitems LEFT JOIN tblinvoices ON tblinvoices.id=tblinvoiceitems.invoiceid WHERE tblinvoiceitems.id=$ID ");
    $res=mysql_fetch_object($r);

    /*  
    $user_id = $r->userid;
    $user = mysql_query("SELECT * FROM tblclients WHERE id=$user_id ");
    $user_data=mysql_fetch_object($user);

    $firstname = $user_data->firstname;
    $lastname = $user_data->lastname;
    $email = $user_data->email;
    $address = $user_data->address;
    $city = $user_data->city;
    $state = $user_data->state;
    $firstname = $params['clientdetails']['firstname'];
    */

     /* if ($products_per_title == '') {
        $post_arr_to_paytabs['products_per_title'] = $res->description;
        $post_arr_to_paytabs['quantity'] = 1;
        $post_arr_to_paytabs['unit_price'] = $amount;
      }*/



      $gateway_url='https://www.paytabs.com/apiv2/create_pay_page';
      $request_string = http_build_query($post_arr_to_paytabs);
      $response_data = paytabs_request($gateway_url, $request_string);

      $redirect_paytabs = json_decode($response_data);
      $url=$redirect_paytabs->payment_url;


      if (isset($_REQUEST['submit'])) {
      echo "<META http-equiv='refresh' content='0;URL=$url'>";die;
      }


      // if(!isset($_GET['action'])){
  
     //Send Invoice
  if (isset($_REQUEST['publishInvoice']) and $_REQUEST['publishInvoice']== 1) {
    $from_email='';
    $qry_from_email= "SELECT value as email FROM tblconfiguration WHERE setting='Email'";
    $row_from_email=mysql_fetch_object(mysql_query($qry_from_email));
    $from_email=$row_from_email->email;
         
  // get from name
    $from_name='';    
    $qry_from_name= "SELECT value as name FROM tblconfiguration WHERE setting='CompanyName'";
    $row_from_name=mysql_fetch_object(mysql_query($qry_from_name));
    $from_name=$row_from_name->name;
     
  //get Signature
    $signature='';
    $qry_email_sign= mysql_query("SELECT value FROM tblconfiguration WHERE setting='Signature'");
    $row_email_sign=mysql_fetch_object($qry_email_sign);
    $signature=$row_email_sign->value;
    
  //get SMTP 
  
    //get Signature
    
    //mail type
    
    $qry_email_mail_type =mysql_query("SELECT value as mail_type FROM tblconfiguration WHERE setting='MailType'");
    $row_email_mail_type=mysql_fetch_object($qry_email_mail_type);
    $mail_type=$row_email_mail_type->mail_type;
    
      //smtp host
    $qry_email_smtp_host =mysql_query("SELECT value as smtp_host FROM tblconfiguration WHERE setting='SMTPHost'");
    $row_email_smtp_host=mysql_fetch_object($qry_email_smtp_host);
    $smtp_host=$row_email_smtp_host->smtp_host;
    //smtp user
    $qry_email_smtp_user =mysql_query("SELECT value as smtp_user FROM tblconfiguration WHERE setting='SMTPUsername'");
    $row_email_smtp_user=mysql_fetch_object($qry_email_smtp_user);
    $smtp_user=$row_email_smtp_user->smtp_user; 
    //smtp pwd
    $qry_email_smtp_pwd =mysql_query("SELECT value as smtp_pwd FROM tblconfiguration WHERE setting='SMTPPassword'");
    $row_email_smtp_pwd=mysql_fetch_object($qry_email_smtp_pwd);
        $smtp_pwd=decrypt($row_email_smtp_pwd->smtp_pwd);   
    
    //smtp port
    
    $qry_email_smtp_port =mysql_query("SELECT value as smtp_port FROM tblconfiguration WHERE setting='SMTPPort'");
    $row_email_smtp_port=mysql_fetch_object($qry_email_smtp_port);
    $smtp_port=$row_email_smtp_port->smtp_port; 
    

    
//**************** GET EMAIL Template ****************************************************
    $qry_email_temp = "SELECT subject,message FROM tblemailtemplates WHERE type='invoice' AND name = 'Invoice Payment Reminder'";
    $row_email_temp=mysql_fetch_object(mysql_query($qry_email_temp ));
    $invoice_subject=$row_email_temp->subject;
    $invoice_message=$row_email_temp->message;

      $ID= $_GET['id'];

      $query = "SELECT inv.userid, CONCAT_WS(' ', c.firstname, c.lastname) as name,c.email,DATE_FORMAT(inv.date,'%d/%m/%y') as inv_created,DATE_FORMAT(inv.duedate,'%d/%m/%y') as inv_duedate,inv.paymentmethod,inv.subtotal as invoice_balance FROM tblinvoices inv INNER JOIN tblclients c ON inv.userid = c.id WHERE inv.id = '" . $ID ."'";

      $row_email=mysql_fetch_object(mysql_query($query));

      $to_email = $row_email->email;

      $subject  = $invoice_subject;


      $email_body=str_replace('{$client_name}',ucwords($row_email->name),$invoice_message);


      $email_body=str_replace('{$invoice_date_created}',$row_email->inv_created,$email_body);


      $email_body=str_replace('{$invoice_date_due}',$row_email->inv_duedate,$email_body);

      $email_body=str_replace('{$invoice_balance}','$'.$row_email->invoice_balance.' '.$currency,$email_body);

      $email_body=str_replace('{$invoice_payment_method}',ucfirst($row_email->paymentmethod),$email_body);

      $email_body=str_replace('{$invoice_num}',$invoice_num,$email_body);

      $invoice_link = $site_url.'/viewinvoice.php?id='.$ID;

      $email_body=str_replace('{$invoice_link}',$invoice_link,$email_body);

      $email_body=str_replace('{$signature}',$signature,$email_body);


     $ss= sendmail($email_body,$to_email,$subject,$from_email,$from_name); 
      //print_r($row_email);
      //print_r($email_body);
      header('Location:'.$send_remainder_redirect);//exit;

      }

//Convert Quote to Invoice
if (isset($_REQUEST['action']) and $_REQUEST['action']=='convert') {
      $send_remainder_redirect=$site_url.'/admin/invoices.php?filter=1';

  header("Location:".$send_remainder_redirect);exit;

}



//click from 
if($_SERVER['PHP_SELF']=='/wshmcs/viewinvoice.php') {

     $ID = $_GET['id'];

    $query = "SELECT *, CONCAT_WS(' ', c.firstname, c.lastname) as name,c.email,DATE_FORMAT(inv.date,'%d/%m/%y') as inv_created,DATE_FORMAT(inv.duedate,'%d/%m/%y') as inv_duedate,inv.paymentmethod,inv.subtotal as invoice_balance FROM tblinvoices inv INNER JOIN tblclients c ON inv.userid = c.id WHERE inv.id = '" . $ID ."'";
    $inv=mysql_fetch_assoc(mysql_query($query));

    $r=mysql_query("SELECT * FROM tblinvoiceitems LEFT JOIN tblinvoices ON tblinvoices.id=tblinvoiceitems.invoiceid WHERE tblinvoiceitems.invoiceid=$ID ");
    $res=mysql_fetch_assoc($r);
  

    $post_arr_to_paytabs=array(
          'merchant_email'   => $Email,
          'secret_key'       => $SecretKey,
          'amount'       => $res['total'],
          'email'        => $inv['email'],
          'billing_address'  => $inv['address1'].' '.$inv['address2'],
          'address_shipping' => $inv['address1'].' '.$inv['address2'],
          'address1'       => $inv['address1'],
          'city'           => $inv['city'],
          'state'          => $inv['state'],
          'city_shipping'    => $inv['city'],
          'state_shipping'   => $inv['state'],
          'country'        => getCountryIsoCode($inv['country']),
          'country_shipping' => getCountryIsoCode($inv['country']),
          'zipcode'        => $inv['postcode'],
          'cc_phone_number'  => getccPhone($inv['country']),
          'cc_first_name'    => $inv['firstname'],
          'cc_last_name'     => $inv['lastname'],
          'phone_number'     => $inv['phonenumber'],
          'postal_code'      => $inv['postcode'],
          'postal_code_shipping'=>$inv['postcode'],
          'currency'         => $currency,
          'title'        => $inv['firstname'].' '.$inv['lastname'],
          'products_per_title'     => $res['description'],
          'description'    => $res['description'],
          'quantity'         => 1,
          'unit_price'       => $res['total'],
          'other_charges'    => 0,
          'return_url'       => $return_url,
          'invoiceid'      => $res['id'],
          'ip_customer'    => $_SERVER['REMOTE_ADDR'],
          'ip_merchant'    => $_SERVER['SERVER_ADDR'],
          'cms_with_version' =>$params['whmcsVersion'],
          'reference_no'     => $res['id'],
          'site_url'         => $protocol.$_SERVER['HTTP_HOST'],
          'msg_lang'         => 'English'
          );

    
      $gateway_url='https://www.paytabs.com/apiv2/create_pay_page';
      $request_string = http_build_query($post_arr_to_paytabs);
      $response_data = paytabs_request($gateway_url, $request_string);
      $redirect_paytabs = json_decode($response_data);
      $url = $redirect_paytabs->payment_url;
   echo "<META http-equiv='refresh' content='0;URL=$url'>";

}//end of condition




    //   
    //s }
      

//******************************* FROM EMAIL *************************************************
 
  //redirect    
  $send_remainder_redirect=$site_url.'/admin/invoices.php?filter=1';

    
          
  // get from email
    $from_email='';
      $qry_from_email= "SELECT value as email FROM tblconfiguration WHERE setting='Email'";
    $row_from_email=mysql_fetch_object(mysql_query($qry_from_email));
    $from_email=$row_from_email->email;
         
  // get from name
    $from_name='';    
    $qry_from_name= "SELECT value as name FROM tblconfiguration WHERE setting='CompanyName'";
    $row_from_name=mysql_fetch_object(mysql_query($qry_from_name));
    $from_name=$row_from_name->name;
      
  //get Signature
      $signature='';
    $qry_email_sign= mysql_query("SELECT value FROM tblconfiguration WHERE setting='Signature'");
    $row_email_sign=mysql_fetch_object($qry_email_sign);
        $signature=$row_email_sign->value;
    
  //get SMTP 
  
    //get Signature
    
    //mail type
    
    $qry_email_mail_type =mysql_query("SELECT value as mail_type FROM tblconfiguration WHERE setting='MailType'");
    $row_email_mail_type=mysql_fetch_object($qry_email_mail_type);
        $mail_type=$row_email_mail_type->mail_type;
    
      //smtp host
    $qry_email_smtp_host =mysql_query("SELECT value as smtp_host FROM tblconfiguration WHERE setting='SMTPHost'");
    $row_email_smtp_host=mysql_fetch_object($qry_email_smtp_host);
        $smtp_host=$row_email_smtp_host->smtp_host;
    //smtp user
    $qry_email_smtp_user =mysql_query("SELECT value as smtp_user FROM tblconfiguration WHERE setting='SMTPUsername'");
    $row_email_smtp_user=mysql_fetch_object($qry_email_smtp_user);
        $smtp_user=$row_email_smtp_user->smtp_user; 
    //smtp pwd
    $qry_email_smtp_pwd =mysql_query("SELECT value as smtp_pwd FROM tblconfiguration WHERE setting='SMTPPassword'");
    $row_email_smtp_pwd=mysql_fetch_object($qry_email_smtp_pwd);
        $smtp_pwd=decrypt($row_email_smtp_pwd->smtp_pwd);   
    
    //smtp port
    
    $qry_email_smtp_port =mysql_query("SELECT value as smtp_port FROM tblconfiguration WHERE setting='SMTPPort'");
    $row_email_smtp_port=mysql_fetch_object($qry_email_smtp_port);
        $smtp_port=$row_email_smtp_port->smtp_port; 
    

    
//**************** GET EMAIL Template ****************************************************
    $qry_email_temp = "SELECT subject,message FROM tblemailtemplates WHERE type='invoice' AND name = 'Invoice Payment Reminder'";
    $row_email_temp=mysql_fetch_object(mysql_query($qry_email_temp ));
    $invoice_subject=$row_email_temp->subject;
    $invoice_message=$row_email_temp->message;


//***************************** End email template ********************************************************************

 
//************************************************ END *********************************************





if($_GET['action']=='edit'){
       
  foreach($_POST['selectedinvoices'] as $invoice_num){

      $query = "SELECT inv.userid, CONCAT_WS(' ', c.firstname, c.lastname) as name,c.email,DATE_FORMAT(inv.date,'%d/%m/%y') as inv_created,DATE_FORMAT(inv.duedate,'%d/%m/%y') as inv_duedate,inv.paymentmethod,inv.subtotal as invoice_balance FROM tblinvoices inv INNER JOIN tblclients c ON inv.userid = c.id WHERE inv.id = '" . $invoice_num ."'";


      $row_email=mysql_fetch_object(mysql_query($query));

      $to_email = $row_email->email;

      $subject  = $invoice_subject;


      $email_body=str_replace('{$client_name}',ucwords($row_email->name),$invoice_message);


      $email_body=str_replace('{$invoice_date_created}',$row_email->inv_created,$email_body);


      $email_body=str_replace('{$invoice_date_due}',$row_email->inv_duedate,$email_body);

      $email_body=str_replace('{$invoice_balance}','$'.$row_email->invoice_balance.$currency,$email_body);

      $email_body=str_replace('{$invoice_payment_method}',ucfirst($row_email->paymentmethod),$email_body);

      $email_body=str_replace('{$invoice_num}',$invoice_num,$email_body);

      $invoice_link = $site_url.'/viewinvoice.php?id='.$invoice_num;

      $email_body=str_replace('{$invoice_link}',$invoice_link,$email_body);

      $email_body=str_replace('{$signature}',$signature,$email_body);


      sendmail($email_body,$to_email,$subject,$from_email,$from_name);

   
    } // end of foreach loop
    //redirect to admin area
         header('Location:'.$send_remainder_redirect);exit;

      }elseif($_GET['filter']=='1' && empty($_POST['selectedinvoices'])){
                         //echo 'in filter';
        // hook_disable_invoice_notification('188');
       // header('Location:'.$send_remainder);exit;
      }elseif(!empty($_POST['paymentreminder'])){
          
          $email_body='';

        foreach($_POST['selectedinvoices'] as $invoice_num){

          $query = "SELECT inv.userid, CONCAT_WS(' ', c.firstname, c.lastname) as name,c.email,DATE_FORMAT(inv.date,'%d/%m/%y') as inv_created,DATE_FORMAT(inv.duedate,'%d/%m/%y') as inv_duedate,inv.paymentmethod,inv.subtotal as invoice_balance FROM tblinvoices inv INNER JOIN tblclients c ON inv.userid = c.id WHERE inv.id = '" . $invoice_num ."'";
            
          $row_email=mysql_fetch_object(mysql_query($query));
          
          $to_email = $row_email->email;
          
          $subject  = $invoice_subject;
          
          
          $email_body=str_replace('{$client_name}',ucwords($row_email->name),$invoice_message);
          
          
          $email_body=str_replace('{$invoice_date_created}',$row_email->inv_created,$email_body);
          
          
          $email_body=str_replace('{$invoice_date_due}',$row_email->inv_duedate,$email_body);
          
          $email_body=str_replace('{$invoice_balance}','$'.$row_email->invoice_balance.' USD',$email_body);
          
          
          $email_body=str_replace('{$invoice_payment_method}',ucfirst($row_email->paymentmethod),$email_body);
          
          $email_body=str_replace('{$invoice_num}',$invoice_num,$email_body);
          
          $invoice_link = $site_url.'/viewinvoice.php?id='.$invoice_num;
          
          $email_body=str_replace('{$invoice_link}',$invoice_link,$email_body);
          
          $email_body=str_replace('{$signature}',$signature,$email_body);
          
          $to_name=$row_email->name;
          
          if($mail_type=='smtp'){
          $sent=sendSMTP($smtp_host,$smtp_user,$smtp_pwd,$smtp_port,$to_email,$to_name,$from_email,$from_name,$subject,$email_body);
            if($sent==0)
               exit;
            
                    }else{


        sendmail($email_body,$to_email,$subject,$from_email,$from_name);
        }

  
  } // end of foreach loop

      //redirect to admin area
  header('Location:'.$send_remainder_redirect);exit;
  } 
    
  else{
   ob_start();
  echo "<center><div class='btn btn-default' style='margin-top:10px;'><a href='?id=".$_REQUEST['id']."&pay'>
          <i class='fa panel-body'>
        Pay Now 
         </i>
          </a></div></center>";
   if (isset($_GET['pay'])) {

    $ID=intval($_GET['id']);
    $r=mysql_query("SELECT * FROM tblinvoiceitems LEFT JOIN tblinvoices ON tblinvoices.id=tblinvoiceitems.invoiceid WHERE tblinvoiceitems.invoiceid=$ID ");
    $res=mysql_fetch_assoc($r);

    $post_arr_to_paytabs['description']=$res['description'];
    $post_arr_to_paytabs['products_per_title']=$res['description'];
    $post_arr_to_paytabs['quantity']=1;
    $post_arr_to_paytabs['unit_price']=$res['total'];
     
    $gateway_url='https://www.paytabs.com/apiv2/create_pay_page';
    $request_string = http_build_query($post_arr_to_paytabs);
    $response_data = paytabs_request($gateway_url, $request_string);
    $redirect_paytabs = json_decode($response_data);
    $url=$redirect_paytabs->payment_url; 
     header('Location:'.$redirect_paytabs->payment_url);exit;

    die;
    }


    if (isset($_GET['a'])) {
      header('Location:'.$redirect_paytabs->payment_url);exit;
    }
    


      //header('Location:'.$send_remainder_redirect);exit;
  }
      
      

      

     } //end of link function



?>